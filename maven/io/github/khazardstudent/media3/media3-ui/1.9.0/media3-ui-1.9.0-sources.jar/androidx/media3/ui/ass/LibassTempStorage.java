/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.ass;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.UnstableApi;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

/** App-private temporary storage for ASS assets (for example, extracted font attachments). */
@UnstableApi
public final class LibassTempStorage implements AutoCloseable {

  private static final String TAG = "LibassTempStorage";

  private final File rootDirectory;

  public LibassTempStorage(Context context, String sessionId) {
    File base = new File(context.getCacheDir(), "libass");
    String safeSessionId =
        sessionId.isEmpty() ? UUID.randomUUID().toString() : sanitizeFileName(sessionId);
    rootDirectory = new File(base, safeSessionId);
    ensureDirectoryExists();
  }

  /** Returns the root directory for this session. */
  public File getRootDirectory() {
    return rootDirectory;
  }

  /**
   * Persists one font blob into the session directory.
   *
   * @return File path on success, or {@code null} if the write failed.
   */
  @Nullable
  public File persistFont(String fileName, byte[] data) {
    return persistFile(fileName, data);
  }

  /**
   * Persists arbitrary session data into the temp directory.
   *
   * @return File path on success, or {@code null} if the write failed.
   */
  @Nullable
  public File persistFile(String fileName, byte[] data) {
    if (data.length == 0 || !ensureDirectoryExists()) {
      return null;
    }
    String safeName = sanitizeFileName(fileName);
    File outputFile = new File(rootDirectory, safeName);
    if (outputFile.exists()) {
      outputFile = new File(rootDirectory, UUID.randomUUID() + "_" + safeName);
    }
    try (FileOutputStream outputStream = new FileOutputStream(outputFile)) {
      outputStream.write(data);
      outputStream.flush();
      return outputFile;
    } catch (IOException e) {
      Log.w(TAG, "Failed to persist font: " + fileName, e);
      // Best effort cleanup of partial files.
      //noinspection ResultOfMethodCallIgnored
      outputFile.delete();
      return null;
    }
  }

  /** Deletes all temporary files for this session. */
  public void clear() {
    deleteRecursively(rootDirectory);
  }

  @Override
  public void close() {
    clear();
  }

  private boolean ensureDirectoryExists() {
    return rootDirectory.exists() || rootDirectory.mkdirs();
  }

  private static String sanitizeFileName(String fileName) {
    String sanitized = fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
    return sanitized.isEmpty() ? "font" : sanitized;
  }

  private static void deleteRecursively(File file) {
    if (!file.exists()) {
      return;
    }
    if (file.isDirectory()) {
      File[] children = file.listFiles();
      if (children != null) {
        for (File child : children) {
          deleteRecursively(child);
        }
      }
    }
    //noinspection ResultOfMethodCallIgnored
    file.delete();
  }
}
