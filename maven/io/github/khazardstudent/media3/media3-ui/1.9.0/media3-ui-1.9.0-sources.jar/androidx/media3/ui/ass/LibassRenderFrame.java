/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.ass;

import android.graphics.Bitmap;
import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;

/** Rendered output frame produced by libass. */
@UnstableApi
public final class LibassRenderFrame {

  /** ARGB frame bitmap for the overlay, or {@code null} when no visible subtitles exist. */
  @Nullable public final Bitmap bitmap;

  /** Presentation timestamp for this frame in microseconds. */
  public final long renderedAtUs;

  /** Whether visual output changed since the previous render call. */
  public final boolean changed;

  public LibassRenderFrame(@Nullable Bitmap bitmap, long renderedAtUs, boolean changed) {
    this.bitmap = bitmap;
    this.renderedAtUs = renderedAtUs;
    this.changed = changed;
  }
}

