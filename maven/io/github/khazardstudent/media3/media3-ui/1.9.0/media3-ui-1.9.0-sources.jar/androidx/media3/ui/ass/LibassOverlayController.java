/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.ass;

import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.ui.PlayerView;

/** Coordinates libass rendering updates and overlay drawing for a {@link PlayerView}. */
@UnstableApi
public final class LibassOverlayController implements Player.Listener, AutoCloseable {

  private static final String TAG = "LibassOverlayCtl";
  private static final boolean DIAGNOSTIC_INFO_LOGS = true;
  private static final long DEFAULT_FRAME_INTERVAL_MS = 16L;
  private static final long MIN_FRAME_INTERVAL_MS = 10L;
  private static final long TRACE_RENDER_LOG_INTERVAL_MS = 750L;
  private static final long TRACE_PERFORMANCE_LOG_INTERVAL_MS = 300L;
  private static final int TRACE_NO_BITMAP_LOG_FRAME_INTERVAL = 30;
  private static final long TRACE_SLOW_RENDER_CALL_LOG_THRESHOLD_MS = 12L;
  private static final long TRACE_SLOW_OVERLAY_APPLY_LOG_THRESHOLD_MS = 8L;
  private static final long TRACE_SLOW_TICK_TOTAL_LOG_THRESHOLD_MS = 20L;
  private static final long TRACE_TICK_DRIFT_LOG_THRESHOLD_MS = 24L;
  private static final long SEEK_BITMAP_CLEAR_GRACE_MS = 160L;
  private static final long SEEK_WAIT_POLL_INTERVAL_MS = 24L;
  private static final long SEEK_WAIT_MAX_MS = 2000L;
  private static final String RENDER_WORKER_THREAD_NAME = "LibassRenderWorker";

  private final Handler mainHandler;
  private final Runnable renderRunnable;
  private final Runnable renderWorkerRunnable;
  private final Object renderRequestLock;
  private final Rect displayRectInOverlay;
  private final Rect overlayRectInPlayer;

  private long frameIntervalMs;
  private boolean frameIntervalOverride;
  private float lastResolvedVideoFrameRate;
  private boolean renderLoopRunning;
  private int lastVideoWidth;
  private int lastVideoHeight;
  private int lastRenderWidth;
  private int lastRenderHeight;
  private long lastSeekPositionUs;
  private boolean waitingForFirstBitmapAfterSeek;
  private int noBitmapFramesSinceSeek;
  private long lastRateLimitedTraceRealtimeMs;
  private long lastPerformanceTraceRealtimeMs;
  private long lastRenderTickRealtimeMs;
  private long seekWaitStartRealtimeMs;
  private boolean seekOverlayClearedWhileWaiting;

  @Nullable private HandlerThread renderWorkerThread;
  @Nullable private Handler renderWorkerHandler;
  private long renderWorkerSessionId;
  private long nextRenderRequestId;
  private long latestAppliedRequestId;
  private long pendingRequestId;
  private long pendingPositionUs;
  private boolean pendingForceRedraw;
  private long pendingEnqueueRealtimeMs;
  private boolean renderWorkerPosted;
  @Nullable private LibassSessionBridge pendingSessionBridge;

  @Nullable private PlayerView playerView;
  @Nullable private Player player;
  @Nullable private LibassSessionBridge sessionBridge;
  @Nullable private LibassOverlayView overlayView;

  public LibassOverlayController() {
    mainHandler = new Handler(Looper.getMainLooper());
    renderRunnable = this::renderTick;
    renderWorkerRunnable = this::renderPendingRequestsOnWorker;
    renderRequestLock = new Object();
    displayRectInOverlay = new Rect();
    overlayRectInPlayer = new Rect();
    frameIntervalMs = DEFAULT_FRAME_INTERVAL_MS;
    frameIntervalOverride = false;
    lastResolvedVideoFrameRate = Format.NO_VALUE;
    lastVideoWidth = -1;
    lastVideoHeight = -1;
    lastRenderWidth = -1;
    lastRenderHeight = -1;
    lastSeekPositionUs = C.TIME_UNSET;
    waitingForFirstBitmapAfterSeek = false;
    noBitmapFramesSinceSeek = 0;
    lastRateLimitedTraceRealtimeMs = 0L;
    lastPerformanceTraceRealtimeMs = 0L;
    lastRenderTickRealtimeMs = 0L;
    seekWaitStartRealtimeMs = C.TIME_UNSET;
    seekOverlayClearedWhileWaiting = false;
    renderWorkerThread = null;
    renderWorkerHandler = null;
    renderWorkerSessionId = 0L;
    nextRenderRequestId = 0L;
    latestAppliedRequestId = 0L;
    pendingRequestId = 0L;
    pendingPositionUs = 0L;
    pendingForceRedraw = false;
    pendingEnqueueRealtimeMs = 0L;
    renderWorkerPosted = false;
    pendingSessionBridge = null;
  }

  /** Sets the periodic render interval used when frame-synced callbacks are unavailable. */
  public void setFrameIntervalMs(long frameIntervalMs) {
    this.frameIntervalMs = Math.max(MIN_FRAME_INTERVAL_MS, frameIntervalMs);
    frameIntervalOverride = true;
  }

  /**
   * Attaches the controller to a {@link PlayerView}.
   *
   * @return Whether attach succeeded and the overlay was mounted.
   */
  public boolean attach(PlayerView playerView, Player player, LibassSessionBridge sessionBridge) {
    detach();
    @Nullable FrameLayout overlayFrameLayout = playerView.getOverlayFrameLayout();
    if (overlayFrameLayout == null) {
      return false;
    }
    this.playerView = playerView;
    this.player = player;
    this.sessionBridge = sessionBridge;
    this.overlayView = new LibassOverlayView(playerView.getContext());
    FrameLayout.LayoutParams layoutParams =
        new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    overlayFrameLayout.addView(this.overlayView, layoutParams);
    startRenderWorker();
    player.addListener(this);
    syncViewport();
    maybeUpdateFrameIntervalFromVideoTrack();
    if (player.isPlaying()) {
      startRenderLoop();
    } else {
      // Render one frame for paused/seeked states.
      renderTick();
    }
    return true;
  }

  /** Detaches from player/view and removes overlay resources. */
  public void detach() {
    stopRenderLoop();
    stopRenderWorker();
    @Nullable Player player = this.player;
    if (player != null) {
      player.removeListener(this);
    }
    @Nullable LibassOverlayView overlayView = this.overlayView;
    if (overlayView != null) {
      @Nullable ViewParent parent = overlayView.getParent();
      if (parent instanceof ViewGroup) {
        ((ViewGroup) parent).removeView(overlayView);
      }
      overlayView.clear();
    }
    this.overlayView = null;
    this.sessionBridge = null;
    this.player = null;
    this.playerView = null;
    frameIntervalOverride = false;
    lastResolvedVideoFrameRate = Format.NO_VALUE;
    frameIntervalMs = DEFAULT_FRAME_INTERVAL_MS;
    lastVideoWidth = -1;
    lastVideoHeight = -1;
    lastRenderWidth = -1;
    lastRenderHeight = -1;
    lastRateLimitedTraceRealtimeMs = 0L;
    lastPerformanceTraceRealtimeMs = 0L;
    lastRenderTickRealtimeMs = 0L;
    lastSeekPositionUs = C.TIME_UNSET;
    waitingForFirstBitmapAfterSeek = false;
    noBitmapFramesSinceSeek = 0;
    seekWaitStartRealtimeMs = C.TIME_UNSET;
    seekOverlayClearedWhileWaiting = false;
  }

  @Override
  public void close() {
    detach();
  }

  @Override
  public void onIsPlayingChanged(boolean isPlaying) {
    if (isPlaying) {
      startRenderLoop();
    } else {
      stopRenderLoop();
      if (waitingForFirstBitmapAfterSeek && lastSeekPositionUs != C.TIME_UNSET) {
        syncViewport();
        queueLatestRenderRequest(lastSeekPositionUs, /* forceRedraw= */ true);
        mainHandler.removeCallbacks(renderRunnable);
        mainHandler.postDelayed(
            renderRunnable, Math.min(frameIntervalMs, SEEK_WAIT_POLL_INTERVAL_MS));
      } else {
        renderTick();
      }
    }
  }

  @Override
  public void onPlaybackStateChanged(@Player.State int playbackState) {
    if (playbackState == Player.STATE_IDLE || playbackState == Player.STATE_ENDED) {
      stopRenderLoop();
      renderTick();
    }
  }

  @Override
  public void onTracksChanged(Tracks tracks) {
    maybeUpdateFrameIntervalFromVideoTrack();
  }

  @Override
  public void onPositionDiscontinuity(
      Player.PositionInfo oldPosition,
      Player.PositionInfo newPosition,
      @Player.DiscontinuityReason int reason) {
    lastSeekPositionUs = newPosition.positionMs * 1000L;
    waitingForFirstBitmapAfterSeek = true;
    noBitmapFramesSinceSeek = 0;
    seekWaitStartRealtimeMs = SystemClock.elapsedRealtime();
    seekOverlayClearedWhileWaiting = false;
    traceAlways(
        "onPositionDiscontinuity reason="
            + reason
            + " oldUs="
            + (oldPosition.positionMs * 1000L)
            + " newUs="
            + lastSeekPositionUs);
    syncViewport();
    queueLatestRenderRequest(lastSeekPositionUs, /* forceRedraw= */ true);
    if (!renderLoopRunning) {
      mainHandler.removeCallbacks(renderRunnable);
      mainHandler.postDelayed(
          renderRunnable, Math.min(frameIntervalMs, SEEK_WAIT_POLL_INTERVAL_MS));
    }
  }

  @Override
  public void onVideoSizeChanged(VideoSize videoSize) {
    traceAlways(
        "onVideoSizeChanged width="
            + videoSize.width
            + " height="
            + videoSize.height
            + " pixelRatio="
            + videoSize.pixelWidthHeightRatio
            + " rotation="
            + videoSize.unappliedRotationDegrees);
    syncViewport();
    maybeUpdateFrameIntervalFromVideoTrack();
    renderTick();
  }

  @Override
  public void onRenderedFirstFrame() {
    traceAlways("onRenderedFirstFrame");
    syncViewport();
    renderTick();
  }

  private void startRenderLoop() {
    if (renderLoopRunning) {
      return;
    }
    renderLoopRunning = true;
    lastRenderTickRealtimeMs = 0L;
    mainHandler.post(renderRunnable);
  }

  private void stopRenderLoop() {
    renderLoopRunning = false;
    mainHandler.removeCallbacks(renderRunnable);
    lastRenderTickRealtimeMs = 0L;
  }

  private void renderTick() {
    @Nullable Player player = this.player;
    if (player == null) {
      return;
    }

    long tickStartRealtimeMs = SystemClock.elapsedRealtime();
    if (renderLoopRunning && lastRenderTickRealtimeMs != 0L) {
      long tickGapMs = tickStartRealtimeMs - lastRenderTickRealtimeMs;
      long expectedTickGapMs = frameIntervalMs;
      if (tickGapMs > expectedTickGapMs + TRACE_TICK_DRIFT_LOG_THRESHOLD_MS) {
        tracePerformanceRateLimited(
            "render tick delayed gapMs="
                + tickGapMs
                + " expectedMs="
                + expectedTickGapMs
                + " posUs="
                + (player.getCurrentPosition() * 1000L)
                + " playing="
                + player.isPlaying());
      }
    }
    lastRenderTickRealtimeMs = tickStartRealtimeMs;

    syncViewport();
    long positionUs = player.getCurrentPosition() * 1000L;
    queueLatestRenderRequest(positionUs, /* forceRedraw= */ waitingForFirstBitmapAfterSeek);

    if (renderLoopRunning || waitingForFirstBitmapAfterSeek) {
      long nextTickDelayMs =
          renderLoopRunning
              ? frameIntervalMs
              : Math.min(frameIntervalMs, SEEK_WAIT_POLL_INTERVAL_MS);
      mainHandler.postDelayed(renderRunnable, nextTickDelayMs);
    }
  }

  private void startRenderWorker() {
    HandlerThread handlerThread = new HandlerThread(RENDER_WORKER_THREAD_NAME);
    handlerThread.start();
    synchronized (renderRequestLock) {
      renderWorkerThread = handlerThread;
      renderWorkerHandler = new Handler(handlerThread.getLooper());
      renderWorkerSessionId++;
      nextRenderRequestId = 0L;
      latestAppliedRequestId = 0L;
      pendingRequestId = 0L;
      pendingPositionUs = 0L;
      pendingForceRedraw = false;
      pendingEnqueueRealtimeMs = 0L;
      renderWorkerPosted = false;
      pendingSessionBridge = null;
    }
  }

  private void stopRenderWorker() {
    @Nullable HandlerThread threadToStop;
    @Nullable Handler workerHandler;
    synchronized (renderRequestLock) {
      renderWorkerSessionId++;
      threadToStop = renderWorkerThread;
      workerHandler = renderWorkerHandler;
      renderWorkerThread = null;
      renderWorkerHandler = null;
      latestAppliedRequestId = 0L;
      pendingRequestId = 0L;
      pendingPositionUs = 0L;
      pendingForceRedraw = false;
      pendingEnqueueRealtimeMs = 0L;
      renderWorkerPosted = false;
      pendingSessionBridge = null;
    }
    if (workerHandler != null) {
      workerHandler.removeCallbacksAndMessages(/* token= */ null);
    }
    if (threadToStop != null) {
      threadToStop.quitSafely();
    }
  }

  private void queueLatestRenderRequest(long positionUs, boolean forceRedraw) {
    @Nullable Handler workerHandler;
    synchronized (renderRequestLock) {
      workerHandler = renderWorkerHandler;
      if (workerHandler == null) {
        return;
      }
      long requestId = ++nextRenderRequestId;
      pendingRequestId = requestId;
      pendingPositionUs = positionUs;
      pendingForceRedraw = pendingForceRedraw || forceRedraw;
      pendingEnqueueRealtimeMs = SystemClock.elapsedRealtime();
      pendingSessionBridge = sessionBridge;
      if (!renderWorkerPosted) {
        renderWorkerPosted = true;
        workerHandler.post(renderWorkerRunnable);
      }
    }
  }

  private void renderPendingRequestsOnWorker() {
    while (true) {
      long sessionId;
      long requestId;
      long positionUs;
      boolean forceRedraw;
      long enqueuedRealtimeMs;
      @Nullable LibassSessionBridge sessionBridge;
      synchronized (renderRequestLock) {
        if (pendingRequestId == 0L) {
          renderWorkerPosted = false;
          return;
        }
        sessionId = renderWorkerSessionId;
        requestId = pendingRequestId;
        positionUs = pendingPositionUs;
        forceRedraw = pendingForceRedraw;
        enqueuedRealtimeMs = pendingEnqueueRealtimeMs;
        sessionBridge = pendingSessionBridge;
        pendingRequestId = 0L;
        pendingPositionUs = 0L;
        pendingForceRedraw = false;
        pendingEnqueueRealtimeMs = 0L;
        pendingSessionBridge = null;
      }
      long renderStartRealtimeMs = SystemClock.elapsedRealtime();
      @Nullable LibassRenderFrame frame =
          sessionBridge != null ? sessionBridge.renderFrame(positionUs, forceRedraw) : null;
      long renderEndRealtimeMs = SystemClock.elapsedRealtime();
      RenderWorkerResult result =
          new RenderWorkerResult(
              sessionId,
              requestId,
              positionUs,
              enqueuedRealtimeMs,
              renderStartRealtimeMs,
              renderEndRealtimeMs,
              frame);
      mainHandler.post(() -> handleRenderWorkerResult(result));
    }
  }

  private void handleRenderWorkerResult(RenderWorkerResult result) {
    long currentSessionId;
    long latestRequestId;
    synchronized (renderRequestLock) {
      currentSessionId = renderWorkerSessionId;
      latestRequestId = latestAppliedRequestId;
    }
    if (result.sessionId != currentSessionId) {
      recycleFrameBitmap(result.frame);
      return;
    }
    if (result.requestId <= latestRequestId) {
      traceRateLimited(
          "drop stale render result requestId="
              + result.requestId
              + " latestAppliedRequestId="
              + latestRequestId
              + " posUs="
              + result.positionUs);
      recycleFrameBitmap(result.frame);
      return;
    }
    synchronized (renderRequestLock) {
      if (result.requestId > latestAppliedRequestId) {
        latestAppliedRequestId = result.requestId;
      }
    }
    @Nullable Player player = this.player;
    @Nullable LibassOverlayView overlayView = this.overlayView;
    if (player == null || overlayView == null) {
      recycleFrameBitmap(result.frame);
      return;
    }

    long positionUs = result.positionUs;
    long renderCallDurationMs = result.renderEndRealtimeMs - result.renderStartRealtimeMs;
    long queueWaitMs = Math.max(0L, result.renderStartRealtimeMs - result.enqueuedRealtimeMs);
    maybeExpireSeekWaitIfNeeded(positionUs);
    long overlayApplyDurationMs = 0L;
    boolean overlayUpdated = false;
    boolean overlayCleared = false;
    @Nullable LibassRenderFrame frame = result.frame;
    boolean frameChanged = frame != null && frame.changed;
    boolean frameHasBitmap = frame != null && frame.bitmap != null;
    if (frame != null) {
      boolean shouldApplyBitmap =
          frame.bitmap != null && (frame.changed || waitingForFirstBitmapAfterSeek);
      if (shouldApplyBitmap) {
        if (waitingForFirstBitmapAfterSeek) {
          waitingForFirstBitmapAfterSeek = false;
          noBitmapFramesSinceSeek = 0;
          seekWaitStartRealtimeMs = C.TIME_UNSET;
          seekOverlayClearedWhileWaiting = false;
          traceAlways(
              "first bitmap after seek; posUs="
                  + positionUs
                  + " seekUs="
                  + lastSeekPositionUs
                  + " deltaMs="
                  + ((positionUs - lastSeekPositionUs) / 1000L)
                  + " changed="
                  + frame.changed
                  + " bitmap="
                  + frame.bitmap.getWidth()
                  + "x"
                  + frame.bitmap.getHeight());
        } else {
          traceRateLimited(
              "render changed=true bitmap="
                  + frame.bitmap.getWidth()
                  + "x"
                  + frame.bitmap.getHeight()
                  + " posUs="
                  + positionUs);
        }
        long overlayApplyStartRealtimeMs = SystemClock.elapsedRealtime();
        overlayView.setRenderFrame(frame);
        overlayApplyDurationMs = SystemClock.elapsedRealtime() - overlayApplyStartRealtimeMs;
        overlayUpdated = true;
      } else if (frame.changed) {
        if (waitingForFirstBitmapAfterSeek) {
          noBitmapFramesSinceSeek++;
          if (noBitmapFramesSinceSeek == 1
              || noBitmapFramesSinceSeek % TRACE_NO_BITMAP_LOG_FRAME_INTERVAL == 0) {
            traceAlways(
                "render changed=true but bitmap=null after seek; posUs="
                    + positionUs
                    + " seekUs="
                    + lastSeekPositionUs
                    + " noBitmapFramesSinceSeek="
                    + noBitmapFramesSinceSeek);
          }
          long clearDurationMs = maybeClearOverlayDuringSeekWait(positionUs, overlayView);
          if (clearDurationMs > 0L) {
            overlayApplyDurationMs += clearDurationMs;
            overlayCleared = true;
          }
        } else {
          traceRateLimited("render changed=true bitmap=null posUs=" + positionUs);
          long overlayApplyStartRealtimeMs = SystemClock.elapsedRealtime();
          overlayView.clear();
          overlayApplyDurationMs = SystemClock.elapsedRealtime() - overlayApplyStartRealtimeMs;
          overlayCleared = true;
        }
      } else if (waitingForFirstBitmapAfterSeek) {
        noBitmapFramesSinceSeek++;
        if (noBitmapFramesSinceSeek == 1
            || noBitmapFramesSinceSeek % TRACE_NO_BITMAP_LOG_FRAME_INTERVAL == 0) {
          traceAlways(
              "waiting first bitmap after seek; frame.changed=false posUs="
                  + positionUs
                  + " seekUs="
                  + lastSeekPositionUs
                  + " noBitmapFramesSinceSeek="
                  + noBitmapFramesSinceSeek);
        }
        long clearDurationMs = maybeClearOverlayDuringSeekWait(positionUs, overlayView);
        if (clearDurationMs > 0L) {
          overlayApplyDurationMs += clearDurationMs;
          overlayCleared = true;
        }
      }
    } else if (waitingForFirstBitmapAfterSeek) {
      noBitmapFramesSinceSeek++;
      if (noBitmapFramesSinceSeek == 1
          || noBitmapFramesSinceSeek % TRACE_NO_BITMAP_LOG_FRAME_INTERVAL == 0) {
        traceAlways(
            "waiting first bitmap after seek; frame=null posUs="
                + positionUs
                + " seekUs="
                + lastSeekPositionUs
                + " noBitmapFramesSinceSeek="
                + noBitmapFramesSinceSeek);
      }
      long clearDurationMs = maybeClearOverlayDuringSeekWait(positionUs, overlayView);
      if (clearDurationMs > 0L) {
        overlayApplyDurationMs += clearDurationMs;
        overlayCleared = true;
      }
    }

    long endToEndDurationMs = Math.max(0L, SystemClock.elapsedRealtime() - result.enqueuedRealtimeMs);
    if (renderCallDurationMs >= TRACE_SLOW_RENDER_CALL_LOG_THRESHOLD_MS
        || overlayApplyDurationMs >= TRACE_SLOW_OVERLAY_APPLY_LOG_THRESHOLD_MS
        || endToEndDurationMs >= TRACE_SLOW_TICK_TOTAL_LOG_THRESHOLD_MS) {
      tracePerformanceRateLimited(
          "slow render tick posUs="
              + positionUs
              + " renderCallMs="
              + renderCallDurationMs
              + " overlayApplyMs="
              + overlayApplyDurationMs
              + " tickTotalMs="
              + endToEndDurationMs
              + " queueWaitMs="
              + queueWaitMs
              + " frameIntervalMs="
              + frameIntervalMs
              + " frameChanged="
              + frameChanged
              + " frameHasBitmap="
              + frameHasBitmap
              + " overlayUpdated="
              + overlayUpdated
              + " overlayCleared="
              + overlayCleared
              + " waitingAfterSeek="
              + waitingForFirstBitmapAfterSeek
              + " playerLoading="
              + (player.getPlaybackState() == Player.STATE_BUFFERING));
    }
  }

  private long maybeClearOverlayDuringSeekWait(long positionUs, LibassOverlayView overlayView) {
    if (seekOverlayClearedWhileWaiting || seekWaitStartRealtimeMs == C.TIME_UNSET) {
      return 0L;
    }
    long waitDurationMs = SystemClock.elapsedRealtime() - seekWaitStartRealtimeMs;
    if (waitDurationMs < SEEK_BITMAP_CLEAR_GRACE_MS) {
      return 0L;
    }
    long overlayApplyStartRealtimeMs = SystemClock.elapsedRealtime();
    overlayView.clear();
    long clearDurationMs = SystemClock.elapsedRealtime() - overlayApplyStartRealtimeMs;
    seekOverlayClearedWhileWaiting = true;
    traceAlways(
        "cleared stale bitmap while waiting first bitmap after seek; posUs="
            + positionUs
            + " waitMs="
            + waitDurationMs);
    return clearDurationMs;
  }

  private void maybeExpireSeekWaitIfNeeded(long positionUs) {
    if (!waitingForFirstBitmapAfterSeek || seekWaitStartRealtimeMs == C.TIME_UNSET) {
      return;
    }
    long waitDurationMs = SystemClock.elapsedRealtime() - seekWaitStartRealtimeMs;
    if (waitDurationMs < SEEK_WAIT_MAX_MS) {
      return;
    }
    waitingForFirstBitmapAfterSeek = false;
    noBitmapFramesSinceSeek = 0;
    seekWaitStartRealtimeMs = C.TIME_UNSET;
    seekOverlayClearedWhileWaiting = false;
    traceAlways(
        "seek wait timed out; stopping forced redraw posUs="
            + positionUs
            + " seekUs="
            + lastSeekPositionUs
            + " waitMs="
            + waitDurationMs);
  }

  private void syncViewport() {
    @Nullable Player player = this.player;
    @Nullable PlayerView playerView = this.playerView;
    @Nullable LibassSessionBridge sessionBridge = this.sessionBridge;
    @Nullable LibassOverlayView overlayView = this.overlayView;
    if (player == null || playerView == null || sessionBridge == null || overlayView == null) {
      return;
    }
    VideoSize videoSize = player.getVideoSize();
    int videoWidth = videoSize.width;
    int videoHeight = videoSize.height;
    if (videoWidth <= 0 || videoHeight <= 0) {
      return;
    }

    int renderWidth;
    int renderHeight;
    if (resolveVideoDisplayRect(playerView, overlayView, displayRectInOverlay)) {
      renderWidth = displayRectInOverlay.width();
      renderHeight = displayRectInOverlay.height();
      overlayView.setVideoDisplayRect(displayRectInOverlay);
    } else {
      int viewWidth = playerView.getWidth();
      int viewHeight = playerView.getHeight();
      if (viewWidth <= 0 || viewHeight <= 0) {
        return;
      }
      renderWidth = viewWidth;
      renderHeight = viewHeight;
      overlayView.setVideoDisplayRect(/* videoDisplayRect= */ null);
    }

    if (renderWidth <= 0 || renderHeight <= 0) {
      return;
    }
    if (videoWidth == lastVideoWidth
        && videoHeight == lastVideoHeight
        && renderWidth == lastRenderWidth
        && renderHeight == lastRenderHeight) {
      return;
    }
    if (sessionBridge.setViewport(videoWidth, videoHeight, renderWidth, renderHeight)) {
      traceAlways(
          "viewport updated video="
              + videoWidth
              + "x"
              + videoHeight
              + " render="
              + renderWidth
              + "x"
              + renderHeight
              + " displayRect="
              + displayRectInOverlay);
      lastVideoWidth = videoWidth;
      lastVideoHeight = videoHeight;
      lastRenderWidth = renderWidth;
      lastRenderHeight = renderHeight;
    }
  }

  private void maybeUpdateFrameIntervalFromVideoTrack() {
    if (frameIntervalOverride) {
      return;
    }
    @Nullable Player player = this.player;
    if (player == null) {
      return;
    }
    float frameRate = resolveSelectedVideoFrameRate(player.getCurrentTracks());
    long newFrameIntervalMs =
        frameRate > 0f
            ? Math.max(MIN_FRAME_INTERVAL_MS, Math.round(1000f / frameRate))
            : DEFAULT_FRAME_INTERVAL_MS;
    if (newFrameIntervalMs == frameIntervalMs
        && Float.compare(frameRate, lastResolvedVideoFrameRate) == 0) {
      return;
    }
    frameIntervalMs = newFrameIntervalMs;
    lastResolvedVideoFrameRate = frameRate;
    traceAlways(
        "subtitle render interval updated intervalMs="
            + frameIntervalMs
            + " videoFps="
            + frameRate);
  }

  private static float resolveSelectedVideoFrameRate(Tracks tracks) {
    float minSelectedVideoFrameRate = Format.NO_VALUE;
    for (int groupIndex = 0; groupIndex < tracks.getGroups().size(); groupIndex++) {
      Tracks.Group group = tracks.getGroups().get(groupIndex);
      if (group.getType() != C.TRACK_TYPE_VIDEO) {
        continue;
      }
      for (int trackIndex = 0; trackIndex < group.length; trackIndex++) {
        if (!group.isTrackSelected(trackIndex)) {
          continue;
        }
        float candidateFrameRate = group.getTrackFormat(trackIndex).frameRate;
        if (candidateFrameRate > 0f
            && (minSelectedVideoFrameRate <= 0f
                || candidateFrameRate < minSelectedVideoFrameRate)) {
          minSelectedVideoFrameRate = candidateFrameRate;
        }
      }
    }
    return minSelectedVideoFrameRate;
  }

  private boolean resolveVideoDisplayRect(
      PlayerView playerView, LibassOverlayView overlayView, Rect outRect) {
    @Nullable View videoSurfaceView = playerView.getVideoSurfaceView();
    if (videoSurfaceView == null
        || videoSurfaceView.getWidth() <= 0
        || videoSurfaceView.getHeight() <= 0
        || overlayView.getWidth() <= 0
        || overlayView.getHeight() <= 0) {
      return false;
    }
    outRect.set(0, 0, videoSurfaceView.getWidth(), videoSurfaceView.getHeight());
    playerView.offsetDescendantRectToMyCoords(videoSurfaceView, outRect);

    overlayRectInPlayer.set(0, 0, overlayView.getWidth(), overlayView.getHeight());
    playerView.offsetDescendantRectToMyCoords(overlayView, overlayRectInPlayer);
    outRect.offset(-overlayRectInPlayer.left, -overlayRectInPlayer.top);
    return !outRect.isEmpty();
  }

  private static void recycleFrameBitmap(@Nullable LibassRenderFrame frame) {
    if (frame == null || frame.bitmap == null || frame.bitmap.isRecycled()) {
      return;
    }
    frame.bitmap.recycle();
  }

  private static final class RenderWorkerResult {
    public final long sessionId;
    public final long requestId;
    public final long positionUs;
    public final long enqueuedRealtimeMs;
    public final long renderStartRealtimeMs;
    public final long renderEndRealtimeMs;
    @Nullable public final LibassRenderFrame frame;

    public RenderWorkerResult(
        long sessionId,
        long requestId,
        long positionUs,
        long enqueuedRealtimeMs,
        long renderStartRealtimeMs,
        long renderEndRealtimeMs,
        @Nullable LibassRenderFrame frame) {
      this.sessionId = sessionId;
      this.requestId = requestId;
      this.positionUs = positionUs;
      this.enqueuedRealtimeMs = enqueuedRealtimeMs;
      this.renderStartRealtimeMs = renderStartRealtimeMs;
      this.renderEndRealtimeMs = renderEndRealtimeMs;
      this.frame = frame;
    }
  }

  private static boolean isTraceEnabled() {
    return Log.isLoggable(TAG, Log.VERBOSE);
  }

  private void traceAlways(String message) {
    if (isTraceEnabled()) {
      Log.v(TAG, message);
      return;
    }
    if (DIAGNOSTIC_INFO_LOGS) {
      Log.i(TAG, message);
    }
  }

  private void traceRateLimited(String message) {
    if (!isTraceEnabled() && !DIAGNOSTIC_INFO_LOGS) {
      return;
    }
    long nowMs = SystemClock.elapsedRealtime();
    if (nowMs - lastRateLimitedTraceRealtimeMs < TRACE_RENDER_LOG_INTERVAL_MS) {
      return;
    }
    lastRateLimitedTraceRealtimeMs = nowMs;
    if (isTraceEnabled()) {
      Log.v(TAG, message);
    } else {
      Log.i(TAG, message);
    }
  }

  private void tracePerformanceRateLimited(String message) {
    if (!isTraceEnabled() && !DIAGNOSTIC_INFO_LOGS) {
      return;
    }
    long nowMs = SystemClock.elapsedRealtime();
    if (nowMs - lastPerformanceTraceRealtimeMs < TRACE_PERFORMANCE_LOG_INTERVAL_MS) {
      return;
    }
    lastPerformanceTraceRealtimeMs = nowMs;
    if (isTraceEnabled()) {
      Log.v(TAG, message);
    } else {
      Log.i(TAG, message);
    }
  }
}
