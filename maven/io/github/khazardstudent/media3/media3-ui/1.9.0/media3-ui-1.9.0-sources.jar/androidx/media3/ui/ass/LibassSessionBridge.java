/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.ass;

import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;

/** Java/JNI bridge for a native libass session. */
@UnstableApi
public final class LibassSessionBridge implements AutoCloseable {

  private static final boolean LIB_LOADED;

  static {
    boolean loaded;
    try {
      // Reuse existing native demuxer lib while the dedicated libass JNI library is introduced.
      System.loadLibrary("ffmpegmkvdemuxer");
      loaded = true;
    } catch (UnsatisfiedLinkError e) {
      loaded = false;
    }
    LIB_LOADED = loaded;
  }

  @Nullable private static final LibassRenderFrame EMPTY_FRAME = null;

  private long handle;

  public LibassSessionBridge() {
    if (LIB_LOADED) {
      try {
        handle = nativeCreateSession();
      } catch (UnsatisfiedLinkError e) {
        handle = 0;
      }
    }
  }

  /** Returns whether the JNI library is loaded and bridge methods can be attempted. */
  public static boolean isAvailable() {
    return LIB_LOADED;
  }

  /** Returns whether a native session handle exists. */
  public synchronized boolean isInitialized() {
    return handle != 0;
  }

  public synchronized boolean setViewport(
      int videoWidth, int videoHeight, int viewWidth, int viewHeight) {
    if (handle == 0) {
      return false;
    }
    try {
      return nativeSetViewport(handle, videoWidth, videoHeight, viewWidth, viewHeight);
    } catch (UnsatisfiedLinkError e) {
      return false;
    }
  }

  public synchronized boolean resetTrack() {
    if (handle == 0) {
      return false;
    }
    try {
      return nativeResetTrack(handle);
    } catch (UnsatisfiedLinkError e) {
      return false;
    }
  }

  public synchronized boolean setCodecPrivate(byte[] codecPrivate) {
    if (handle == 0) {
      return false;
    }
    try {
      return nativeSetCodecPrivate(handle, codecPrivate);
    } catch (UnsatisfiedLinkError e) {
      return false;
    }
  }

  public synchronized int addEmbeddedFont(String fileName, @Nullable String mimeType, byte[] data) {
    if (handle == 0) {
      return -1;
    }
    try {
      return nativeAddEmbeddedFont(handle, fileName, mimeType, data);
    } catch (UnsatisfiedLinkError e) {
      return -1;
    }
  }

  /**
   * Adds an embedded font file from app-private storage.
   *
   * <p>This avoids holding large font blobs in memory for low-RAM TV devices.
   */
  public synchronized int addEmbeddedFontFile(
      String fileName, @Nullable String mimeType, String filePath) {
    if (handle == 0) {
      return -1;
    }
    try {
      return nativeAddEmbeddedFontFile(handle, fileName, mimeType, filePath);
    } catch (UnsatisfiedLinkError e) {
      return -1;
    }
  }

  public synchronized int pushEvent(byte[] assData, long startUs, long durationUs) {
    if (handle == 0) {
      return -1;
    }
    try {
      return nativePushEvent(handle, assData, startUs, durationUs);
    } catch (UnsatisfiedLinkError e) {
      return -1;
    }
  }

  /** Loads a full ASS script from a local file path. */
  public synchronized boolean loadTrackFromFile(String filePath) {
    if (handle == 0) {
      return false;
    }
    try {
      return nativeLoadTrackFromFile(handle, filePath);
    } catch (UnsatisfiedLinkError e) {
      return false;
    }
  }

  @Nullable
  public synchronized LibassRenderFrame renderFrame(long positionUs) {
    return renderFrame(positionUs, /* forceRedraw= */ false);
  }

  @Nullable
  public synchronized LibassRenderFrame renderFrame(long positionUs, boolean forceRedraw) {
    if (handle == 0) {
      return EMPTY_FRAME;
    }
    try {
      return nativeRenderFrame(handle, positionUs, forceRedraw);
    } catch (UnsatisfiedLinkError e) {
      return EMPTY_FRAME;
    }
  }

  public synchronized boolean onSeek(long positionUs) {
    if (handle == 0) {
      return false;
    }
    try {
      return nativeOnSeek(handle, positionUs);
    } catch (UnsatisfiedLinkError e) {
      return false;
    }
  }

  @Override
  public synchronized void close() {
    if (handle == 0) {
      return;
    }
    try {
      nativeDestroySession(handle);
    } catch (UnsatisfiedLinkError e) {
      // Ignore and drop handle.
    }
    handle = 0;
  }

  private static native long nativeCreateSession();

  private static native void nativeDestroySession(long handle);

  private static native boolean nativeSetViewport(
      long handle, int videoWidth, int videoHeight, int viewWidth, int viewHeight);

  private static native boolean nativeResetTrack(long handle);

  private static native boolean nativeSetCodecPrivate(long handle, byte[] codecPrivate);

  private static native int nativeAddEmbeddedFont(
      long handle, String fileName, @Nullable String mimeType, byte[] data);

  private static native int nativeAddEmbeddedFontFile(
      long handle, String fileName, @Nullable String mimeType, String filePath);

  private static native int nativePushEvent(
      long handle, byte[] assData, long startUs, long durationUs);

  private static native boolean nativeLoadTrackFromFile(long handle, String filePath);

  @Nullable
  private static native LibassRenderFrame nativeRenderFrame(
      long handle, long positionUs, boolean forceRedraw);

  private static native boolean nativeOnSeek(long handle, long positionUs);
}
