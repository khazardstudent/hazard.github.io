/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.ass;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;

/** Simple overlay view that draws bitmap frames produced by libass. */
@UnstableApi
public final class LibassOverlayView extends View {

  private final Rect bitmapDestRect;
  private final Rect videoDestRect;
  private final Paint bitmapPaint;

  @Nullable private LibassRenderFrame currentFrame;

  public LibassOverlayView(Context context) {
    this(context, /* attrs= */ null);
  }

  public LibassOverlayView(Context context, @Nullable AttributeSet attrs) {
    super(context, attrs);
    bitmapDestRect = new Rect();
    videoDestRect = new Rect();
    bitmapPaint = new Paint();
    bitmapPaint.setFilterBitmap(true);
    bitmapPaint.setAntiAlias(true);
    setWillNotDraw(false);
  }

  /** Sets the frame to render. Passing {@code null} clears the overlay. */
  public void setRenderFrame(@Nullable LibassRenderFrame frame) {
    releaseFrameBitmap(currentFrame);
    currentFrame = frame;
    invalidate();
  }

  /** Clears the currently rendered frame. */
  public void clear() {
    releaseFrameBitmap(currentFrame);
    currentFrame = null;
    invalidate();
  }

  /**
   * Sets the destination rectangle for subtitle rendering within this view.
   *
   * <p>If unset, subtitles are rendered across the full view bounds.
   */
  public void setVideoDisplayRect(@Nullable Rect videoDisplayRect) {
    if (videoDisplayRect == null || videoDisplayRect.isEmpty()) {
      if (!videoDestRect.isEmpty()) {
        videoDestRect.setEmpty();
        invalidate();
      }
      return;
    }
    if (videoDestRect.equals(videoDisplayRect)) {
      return;
    }
    videoDestRect.set(videoDisplayRect);
    invalidate();
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    @Nullable LibassRenderFrame frame = currentFrame;
    if (frame == null) {
      return;
    }
    @Nullable Bitmap bitmap = frame.bitmap;
    if (bitmap == null || bitmap.isRecycled()) {
      return;
    }
    if (videoDestRect.isEmpty()) {
      bitmapDestRect.set(0, 0, getWidth(), getHeight());
    } else {
      bitmapDestRect.set(videoDestRect);
      bitmapDestRect.left = Math.max(0, bitmapDestRect.left);
      bitmapDestRect.top = Math.max(0, bitmapDestRect.top);
      bitmapDestRect.right = Math.min(getWidth(), bitmapDestRect.right);
      bitmapDestRect.bottom = Math.min(getHeight(), bitmapDestRect.bottom);
    }
    if (bitmapDestRect.isEmpty()) {
      return;
    }
    canvas.drawBitmap(bitmap, /* src= */ null, bitmapDestRect, bitmapPaint);
  }

  private static void releaseFrameBitmap(@Nullable LibassRenderFrame frame) {
    if (frame == null || frame.bitmap == null || frame.bitmap.isRecycled()) {
      return;
    }
    frame.bitmap.recycle();
  }
}
