/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.exoplayer.ffmpeg;

import static android.os.Build.VERSION.SDK_INT;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.view.Display;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector;
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil;
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil.DecoderQueryException;
import androidx.media3.extractor.ffmpeg.FfmpegFilteringLibrary;
import androidx.media3.extractor.ffmpeg.FfmpegFilteringMode;
import java.util.List;

/** Helper that resolves AUTO filtering mode based on device/display capabilities. */
@UnstableApi
public final class HdrFilteringChooser {

  private static final String TAG = "HdrFilteringChooser";

  private HdrFilteringChooser() {}

  /**
   * Resolves the actual filtering mode to use, turning {@link FfmpegFilteringMode#AUTO} into a
   * concrete selection based on device support.
   */
  public static @FfmpegFilteringMode.Mode int resolveMode(
      Context context, @FfmpegFilteringMode.Mode int requestedMode) {
    if (requestedMode != FfmpegFilteringMode.AUTO) {
      return requestedMode;
    }
    if (!FfmpegFilteringLibrary.isAvailable()) {
      return FfmpegFilteringMode.AUTO;
    }
    if (supportsDolbyVision(context)) {
      return FfmpegFilteringMode.KEEP_DOLBY_VISION;
    }
    return FfmpegFilteringMode.KEEP_HDR10_BASE;
  }

  /** Returns true if the device and default display can render Dolby Vision. */
  public static boolean supportsDolbyVision(Context context) {
    if (SDK_INT < 24 || !hasHdrDisplay(context, Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION)) {
      return false;
    }
    return hasDecoder(MimeTypes.VIDEO_DOLBY_VISION);
  }

  /** Returns true if HDR10/HDR10+ rendering is possible. */
  public static boolean supportsHdr10(Context context) {
    if (SDK_INT < 24) {
      return false;
    }
    if (hasHdrDisplay(context, Display.HdrCapabilities.HDR_TYPE_HDR10)
        || (SDK_INT >= 29
            && hasHdrDisplay(context, Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS))) {
      return true;
    }
    return hasDecoder(MimeTypes.VIDEO_H265);
  }

  private static boolean hasDecoder(String mimeType) {
    try {
      Format format = new Format.Builder().setSampleMimeType(mimeType).build();
      List<androidx.media3.exoplayer.mediacodec.MediaCodecInfo> infos =
          MediaCodecUtil.getDecoderInfosSoftMatch(
              MediaCodecSelector.DEFAULT, format, /* requiresSecureDecoder= */ false,
              /* requiresTunnelingDecoder= */ false);
      return !infos.isEmpty();
    } catch (DecoderQueryException e) {
      Log.w(TAG, "Decoder query failed for mime " + mimeType, e);
      return false;
    }
  }

  private static boolean hasHdrDisplay(Context context, int hdrType) {
    Display display = getDefaultDisplay(context);
    if (display == null || !display.isHdr()) {
      return false;
    }
    int[] supportedHdrTypes = display.getHdrCapabilities().getSupportedHdrTypes();
    for (int supported : supportedHdrTypes) {
      if (supported == hdrType) {
        return true;
      }
    }
    return false;
  }

  private static Display getDefaultDisplay(Context context) {
    DisplayManager displayManager =
        (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
    return displayManager != null ? displayManager.getDisplay(Display.DEFAULT_DISPLAY) : null;
  }
}
