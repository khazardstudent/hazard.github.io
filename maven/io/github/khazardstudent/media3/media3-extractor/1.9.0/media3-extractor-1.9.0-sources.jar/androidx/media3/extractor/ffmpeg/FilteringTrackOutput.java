/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ffmpeg;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.DataReader;
import androidx.media3.common.Format;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.extractor.ForwardingTrackOutput;
import androidx.media3.extractor.TrackOutput;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;

/** TrackOutput that hands sample data to an {@link FfmpegFilteringSession}. */
@UnstableApi
public final class FilteringTrackOutput extends ForwardingTrackOutput {

  private final FfmpegFilteringSession session;
  private final @C.TrackType int trackType;

  private @Nullable Format currentFormat;
  private @Nullable Format adjustedFormat;
  private boolean filteringEnabled;
  private @Nullable ByteArrayOutputStream sampleBuffer;
  private int forwardedBytesForSample;

  // Scratch for HDR10+ SEI parsed from filtered samples.
  private static final class Hdr10PlusParser {
    private static final int NAL_SEI_PREFIX = 39;
    private static final int NAL_SEI_SUFFIX = 40;

    private static boolean isStartCode(byte[] data, int offset, int limit) {
      if (offset + 3 >= limit) {
        return false;
      }
      return data[offset] == 0x00
          && data[offset + 1] == 0x00
          && ((data[offset + 2] == 0x01) || (offset + 4 < limit && data[offset + 2] == 0x00 && data[offset + 3] == 0x01));
    }

    private static int nalType(byte b0) {
      return (b0 >> 1) & 0x3F;
    }

    private static @Nullable byte[] parseSeiPayload(byte[] data, int offset, int limit) {
      // Skip NAL header (2 bytes for HEVC).
      int pos = offset + 2;
      while (pos + 2 <= limit) {
        int payloadType = 0;
        while (pos < limit && data[pos] == (byte) 0xFF) {
          payloadType += 0xFF;
          pos++;
        }
        if (pos >= limit) break;
        payloadType += (data[pos] & 0xFF);
        pos++;

        int payloadSize = 0;
        while (pos < limit && data[pos] == (byte) 0xFF) {
          payloadSize += 0xFF;
          pos++;
        }
        if (pos >= limit) break;
        payloadSize += (data[pos] & 0xFF);
        pos++;

        if (pos + payloadSize > limit) break;
        if (payloadType == 4 && payloadSize >= 5) {
          // T.35: country_code 0xB5, provider_code 0x003C, user_identifier 0x0001
          int p = pos;
          if ((data[p] & 0xFF) == 0xB5
              && (data[p + 1] & 0xFF) == 0x00
              && (data[p + 2] & 0xFF) == 0x3C
              && (data[p + 3] & 0xFF) == 0x00
              && (data[p + 4] & 0xFF) == 0x01) {
            byte[] out = new byte[payloadSize];
            System.arraycopy(data, pos, out, 0, payloadSize);
            return out;
          }
        }
        pos += payloadSize;
      }
      return null;
    }

    static @Nullable byte[] extract(byte[] sample, int length) {
      // Detect length-prefixed vs annex-b
      if (length < 6) return null;

      boolean isAnnexB = isStartCode(sample, 0, length);
      if (isAnnexB) {
        int pos = 0;
        while (true) {
          // find start code
          int scPos = -1;
          int scLen = 0;
          for (int i = pos; i + 3 < length; i++) {
            if (isStartCode(sample, i, length)) {
              scPos = i;
              scLen = (sample[i + 2] == 0x01) ? 3 : 4;
              break;
            }
          }
          if (scPos < 0) break;
          int nalStart = scPos + scLen;
          int nextSc = length;
          for (int i = nalStart; i + 3 < length; i++) {
            if (isStartCode(sample, i, length)) {
              nextSc = i;
              break;
            }
          }
          int nalSize = nextSc - nalStart;
          if (nalSize > 2) {
            int type = nalType(sample[nalStart]);
            if (type == NAL_SEI_PREFIX || type == NAL_SEI_SUFFIX) {
              byte[] hdr10p = parseSeiPayload(sample, nalStart, nalStart + nalSize);
              if (hdr10p != null) return hdr10p;
            }
          }
          pos = nextSc;
        }
        return null;
      }

      // length-prefixed (4-byte)
      int pos = 0;
      while (pos + 4 <= length) {
        int nalSize =
            ((sample[pos] & 0xFF) << 24)
                | ((sample[pos + 1] & 0xFF) << 16)
                | ((sample[pos + 2] & 0xFF) << 8)
                | (sample[pos + 3] & 0xFF);
        pos += 4;
        if (nalSize <= 0 || pos + nalSize > length) {
          break;
        }
        int type = nalType(sample[pos]);
        if (type == NAL_SEI_PREFIX || type == NAL_SEI_SUFFIX) {
          byte[] hdr10p = parseSeiPayload(sample, pos, pos + nalSize);
          if (hdr10p != null) return hdr10p;
        }
        pos += nalSize;
      }
      return null;
    }
  }

  public FilteringTrackOutput(
      TrackOutput delegate, FfmpegFilteringSession session, @C.TrackType int trackType) {
    super(delegate);
    this.session = session;
    this.trackType = trackType;
  }

  @Override
  public void format(Format format) {
    currentFormat = format;
    adjustedFormat = session.adjustFormat(format, trackType);
    filteringEnabled = session.shouldFilterTrack(trackType, format);
    super.format(adjustedFormat);
  }

  @Override
  public int sampleData(
      DataReader input, int length, boolean allowEndOfInput, @SampleDataPart int sampleDataPart)
      throws IOException {
    if (!shouldBuffer(sampleDataPart)) {
      int written = super.sampleData(input, length, allowEndOfInput, sampleDataPart);
      maybeTrackForwardedBytes(sampleDataPart, written);
      return written;
    }
    ensureBuffer();
    byte[] data = new byte[length];
    int read = input.read(data, /* offset= */ 0, length);
    if (read == C.RESULT_END_OF_INPUT) {
      if (allowEndOfInput) {
        return C.RESULT_END_OF_INPUT;
      }
      throw new EOFException();
    }
    sampleBuffer.write(data, /* off= */ 0, read);
    return read;
  }

  @Override
  public void sampleData(ParsableByteArray data, int length, @SampleDataPart int sampleDataPart) {
    if (!shouldBuffer(sampleDataPart)) {
      super.sampleData(data, length, sampleDataPart);
      maybeTrackForwardedBytes(sampleDataPart, length);
      return;
    }
    ensureBuffer();
    int cappedLength = Math.min(length, data.bytesLeft());
    sampleBuffer.write(data.getData(), data.getPosition(), cappedLength);
    data.skipBytes(cappedLength);
  }

  @Override
  public void sampleMetadata(
      long timeUs,
      @C.BufferFlags int flags,
      int size,
      int offset,
      @Nullable CryptoData cryptoData) {
    if (!filteringEnabled || sampleBuffer == null || currentFormat == null) {
      super.sampleMetadata(timeUs, flags, size, offset, cryptoData);
      resetBufferingState();
      return;
    }

    byte[] rawSample = sampleBuffer.toByteArray();
    sampleBuffer.reset();
    Format formatForFiltering = adjustedFormat != null ? adjustedFormat : currentFormat;
    FfmpegFilteringSession.FilteringResult filtered =
        session.filterSampleData(
            formatForFiltering, rawSample, rawSample.length, timeUs, flags);

    ParsableByteArray filteredData = new ParsableByteArray(filtered.data, filtered.length);
    super.sampleData(filteredData, filtered.length, SAMPLE_DATA_PART_MAIN);
    int filteredSize = forwardedBytesForSample + filtered.length;
    // Filtered data may have DV RPUs or HDR10+ SEI removed depending on the selected mode.
    super.sampleMetadata(timeUs, filtered.flags, filteredSize, offset, cryptoData);
    resetBufferingState();
  }

  private boolean shouldBuffer(@SampleDataPart int sampleDataPart) {
    return filteringEnabled && sampleDataPart == SAMPLE_DATA_PART_MAIN;
  }

  private void ensureBuffer() {
    if (sampleBuffer == null) {
      sampleBuffer = new ByteArrayOutputStream();
    }
  }

  private void maybeTrackForwardedBytes(@SampleDataPart int sampleDataPart, int length) {
    if (filteringEnabled && sampleDataPart != SAMPLE_DATA_PART_MAIN && length > 0) {
      forwardedBytesForSample += length;
    }
  }

  private void resetBufferingState() {
    forwardedBytesForSample = 0;
    if (sampleBuffer != null) {
      sampleBuffer.reset();
    }
  }
}
