/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ffmpeg;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.container.DolbyVisionConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import android.util.Log;

/** Session holder for FFmpeg-based DV/HDR filtering. */
@UnstableApi
public class FfmpegFilteringSession implements AutoCloseable {

  private static final String TAG = "FfmpegFiltering";

  /** Result of filtering a single sample. */
  public static final class FilteringResult {
    public final byte[] data;
    public final int length;
    public final @C.BufferFlags int flags;

    public FilteringResult(byte[] data, int length, @C.BufferFlags int flags) {
      this.data = data;
      this.length = length;
      this.flags = flags;
    }
  }

  /** Factory for creating sessions. */
  public interface Factory {
    FfmpegFilteringSession create(@FfmpegFilteringMode.Mode int mode);
  }

  private final @FfmpegFilteringMode.Mode int mode;
  private final boolean active;

  /** Creates a session that is active only if the FFmpeg library is available. */
  public static FfmpegFilteringSession create(@FfmpegFilteringMode.Mode int mode) {
    return new FfmpegFilteringSession(mode, FfmpegFilteringLibrary.isAvailable());
  }

  /** Returns a factory that creates sessions using {@link #create(int)}. */
  public static Factory defaultFactory() {
    return FfmpegFilteringSession::create;
  }

  protected FfmpegFilteringSession(@FfmpegFilteringMode.Mode int mode, boolean active) {
    this.mode = mode;
    this.active = active;
  }

  /** Returns whether filtering work should be attempted. */
  public final boolean isActive() {
    return active;
  }

  /** Returns the configured mode. */
  public final @FfmpegFilteringMode.Mode int getMode() {
    return mode;
  }

  /**
   * Returns whether samples for the given track should be filtered. Default filters only video when
   * active and mode is not {@link FfmpegFilteringMode#AUTO}.
   */
  public boolean shouldFilterTrack(@C.TrackType int trackType, @Nullable Format format) {
    if (!active || mode == FfmpegFilteringMode.AUTO || trackType != C.TRACK_TYPE_VIDEO) {
      return false;
    }
    if (format == null) {
      // Defer until we see the Format to avoid wrapping non-HEVC tracks.
      Log.i(TAG, "Track type=video format unknown yet; tentatively enabling filtering");
      return true;
    }
    if (isDolbyVision(format)) {
      // DV streams can be filtered in either mode:
      // - KEEP_HDR10_BASE strips DV NALs.
      // - KEEP_DOLBY_VISION strips HDR10+ SEI while keeping DV.
      boolean shouldFilter =
          mode == FfmpegFilteringMode.KEEP_HDR10_BASE
              || mode == FfmpegFilteringMode.KEEP_DOLBY_VISION
              || mode == FfmpegFilteringMode.KEEP_DOLBY_VISION_MEL;
      Log.i(
          TAG,
          "Dolby Vision detected; mode="
              + mode
              + " shouldFilter="
              + shouldFilter
              + " willFilter="
              + shouldFilter);
      return shouldFilter;
    }
    boolean shouldFilter = isHevcLike(format);
    if (!shouldFilter) {
      Log.i(
          TAG,
          "Skipping filtering for video track, mime="
              + format.sampleMimeType
              + " codecs="
              + format.codecs
              + " mode="
              + mode);
    }
    return shouldFilter;
  }

  /** Adjusts the format to reflect filtering; default returns the original format. */
  public Format adjustFormat(Format format, @C.TrackType int trackType) {
    if (mode == FfmpegFilteringMode.KEEP_HDR10_BASE && trackType == C.TRACK_TYPE_VIDEO) {
      if (isDolbyVision(format)) {
        // We’re stripping DV; surface a plain HEVC format to avoid DV decoder selection and keep
        // HDR10/HDR10+ metadata intact.
        return format
            .buildUpon()
            .setSampleMimeType(MimeTypes.VIDEO_H265)
            .setCodecs(mapDolbyVisionCodecsToHevc(format.codecs))
            .setInitializationData(stripDolbyVisionInitializationData(format.initializationData))
            .build();
      }
    }
    return format;
  }

  /**
   * Filters the provided sample data. The default implementation is a no-op passthrough.
   *
   * @param format The track format.
   * @param sampleData The sample data.
   * @param length The number of valid bytes in {@code sampleData}.
   * @param timeUs The sample timestamp.
   * @param flags Buffer flags for the sample.
   */
  public FilteringResult filterSampleData(
      Format format, byte[] sampleData, int length, long timeUs, @C.BufferFlags int flags) {
    if (!active) {
      Log.i(TAG, "Filtering inactive; passing through sample mime=" + format.sampleMimeType);
      return new FilteringResult(sampleData, length, flags);
    }
    if (!isHevcLike(format)) {
      Log.i(
          TAG,
          "Filtering disabled for non-HEVC sample mime="
              + format.sampleMimeType
              + " codecs="
              + format.codecs);
      return new FilteringResult(sampleData, length, flags);
    }
    Log.i(
        TAG,
        "Filtering sample mode="
            + mode
            + " mime="
            + format.sampleMimeType
            + " codecs="
            + format.codecs
            + " size="
            + length);
    int nalLengthSize = getHevcNalLengthSize(format);
    byte[] filtered =
        FfmpegFilteringNative.filter(
            mode,
            format.sampleMimeType,
            format.codecs,
            nalLengthSize,
            sampleData,
            length,
            timeUs,
            flags);
    return new FilteringResult(filtered, filtered.length, flags);
  }

  /** Releases any native resources. Default implementation is a no-op. */
  @Override
  public void close() {
    // No-op for placeholder session.
  }

  private static boolean isHevcLike(Format format) {
    if (format.sampleMimeType != null) {
      if (format.sampleMimeType.equals(MimeTypes.VIDEO_H265)
          || format.sampleMimeType.equals(MimeTypes.VIDEO_DOLBY_VISION)) {
        return true;
      }
    }
    if (format.codecs == null) {
      return false;
    }
    String codecsLower = format.codecs.toLowerCase(Locale.US);
    return codecsLower.startsWith("dvhe")
        || codecsLower.startsWith("dvh1")
        || codecsLower.startsWith("hvc1")
        || codecsLower.startsWith("hev1");
  }

  private static boolean isDolbyVision(Format format) {
    if (MimeTypes.VIDEO_DOLBY_VISION.equals(format.sampleMimeType)) {
      return true;
    }
    if (format.codecs == null) {
      return false;
    }
    String codecsLower = format.codecs.toLowerCase(Locale.US);
    return codecsLower.startsWith("dvhe") || codecsLower.startsWith("dvh1");
  }

  private static @Nullable String stripDolbyVisionCodecs(@Nullable String codecs) {
    if (codecs == null) {
      return null;
    }
    String codecsLower = codecs.toLowerCase(Locale.US);
    if (codecsLower.startsWith("dvhe") || codecsLower.startsWith("dvh1")) {
      return null;
    }
    return codecs;
  }

  /**
   * Maps DV codec strings to a generic HEVC codec so decoders that expect an HEVC label can still
   * configure properly once DV metadata has been stripped.
   */
  private static @Nullable String mapDolbyVisionCodecsToHevc(@Nullable String codecs) {
    if (codecs == null) {
      return null;
    }
    String lower = codecs.toLowerCase(Locale.US);
    if (lower.startsWith("dvhe") || lower.startsWith("dvh1")) {
      // Use a neutral HEVC codec string; most TVs accept "hvc1".
      return "hvc1";
    }
    return codecs;
  }

  private static List<byte[]> stripDolbyVisionInitializationData(
      @Nullable List<byte[]> initializationData) {
    if (initializationData == null || initializationData.isEmpty()) {
      return initializationData;
    }
    boolean removed = false;
    ArrayList<byte[]> filtered = new ArrayList<>(initializationData.size());
    for (byte[] csd : initializationData) {
      if (csd != null && isDolbyVisionConfig(csd)) {
        removed = true;
        continue;
      }
      filtered.add(csd);
    }
    if (!removed) {
      return initializationData;
    }
    if (filtered.isEmpty()) {
      return Collections.emptyList();
    }
    return Collections.unmodifiableList(filtered);
  }


  private static boolean isDolbyVisionConfig(byte[] data) {
    // Dolby Vision config boxes are 24-byte payloads; guard for short buffers and parse defensively.
    if (data.length < 4) {
      return false;
    }
    try {
      return DolbyVisionConfig.parse(new ParsableByteArray(data)) != null;
    } catch (Exception e) {
      return false;
    }
  }

  private static int getHevcNalLengthSize(Format format) {
    if (format.initializationData == null || format.initializationData.isEmpty()) {
      return 0;
    }
    for (byte[] csd : format.initializationData) {
      if (csd == null || csd.length < 22) {
        continue;
      }
      // HEVCDecoderConfigurationRecord lengthSizeMinusOne is stored at byte 21 (0-based).
      int lengthSizeMinusOne = csd[21] & 0x03;
      int lengthSize = lengthSizeMinusOne + 1;
      if (lengthSize >= 1 && lengthSize <= 4) {
        return lengthSize;
      }
    }
    return 0;
  }
}
