/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ffmpeg;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.ForwardingExtractor;

/** Wraps an {@link Extractor} to feed sample data through {@link FfmpegFilteringSession}. */
@UnstableApi
public final class FfmpegFilteringExtractorAdapter extends ForwardingExtractor {

  private final @FfmpegFilteringMode.Mode int mode;
  private final FfmpegFilteringSession.Factory sessionFactory;

  private FfmpegFilteringSession session;

  public FfmpegFilteringExtractorAdapter(Extractor extractor, @FfmpegFilteringMode.Mode int mode) {
    this(extractor, mode, FfmpegFilteringSession.defaultFactory());
  }

  public FfmpegFilteringExtractorAdapter(
      Extractor extractor,
      @FfmpegFilteringMode.Mode int mode,
      FfmpegFilteringSession.Factory sessionFactory) {
    super(extractor);
    this.mode = mode;
    this.sessionFactory = sessionFactory;
  }

  @Override
  public void init(ExtractorOutput output) {
    session = sessionFactory.create(mode);
    if (session.isActive()) {
      super.init(new FilteringExtractorOutput(output, session));
    } else {
      super.init(output);
    }
  }

  @Override
  public void release() {
    if (session != null) {
      session.close();
      session = null;
    }
    super.release();
  }
}
