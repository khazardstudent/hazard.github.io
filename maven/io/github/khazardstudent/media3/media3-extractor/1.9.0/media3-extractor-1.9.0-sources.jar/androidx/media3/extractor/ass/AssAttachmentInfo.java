/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.extractor.ass;

import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;

/** Information for one MKV attachment used by ASS/SSA rendering. */
@UnstableApi
public final class AssAttachmentInfo {

  /** Attachment file name (for example, a font file name). */
  public final String fileName;

  /** Attachment MIME type. */
  @Nullable public final String mimeType;

  /** Raw attachment payload. */
  public final byte[] data;

  public AssAttachmentInfo(String fileName, @Nullable String mimeType, byte[] data) {
    this.fileName = fileName;
    this.mimeType = mimeType;
    this.data = data;
  }
}

