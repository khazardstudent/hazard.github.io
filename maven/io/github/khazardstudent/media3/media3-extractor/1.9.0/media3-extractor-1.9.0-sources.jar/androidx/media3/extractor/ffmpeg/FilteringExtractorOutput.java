/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ffmpeg;

import androidx.media3.common.C;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.ForwardingExtractorOutput;
import androidx.media3.extractor.TrackOutput;

/** Wraps an {@link ExtractorOutput} to apply FFmpeg filtering to selected tracks. */
@UnstableApi
public final class FilteringExtractorOutput extends ForwardingExtractorOutput {

  private final FfmpegFilteringSession session;

  public FilteringExtractorOutput(ExtractorOutput output, FfmpegFilteringSession session) {
    super(output);
    this.session = session;
  }

  @Override
  public TrackOutput track(int id, @C.TrackType int type) {
    TrackOutput delegate = super.track(id, type);
    if (!session.shouldFilterTrack(type, /* format= */ null)) {
      return delegate;
    }
    return new FilteringTrackOutput(delegate, session, type);
  }
}
