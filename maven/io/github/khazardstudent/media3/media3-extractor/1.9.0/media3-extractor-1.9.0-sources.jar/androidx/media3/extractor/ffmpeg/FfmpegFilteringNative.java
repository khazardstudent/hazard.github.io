/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ffmpeg;

import androidx.media3.common.util.UnstableApi;

/** JNI bridge for FFmpeg-based filtering. */
@UnstableApi
public final class FfmpegFilteringNative {

  private FfmpegFilteringNative() {}

  static {
    FfmpegFilteringLibrary.isAvailable();
  }

  public static native byte[] filter(
      @FfmpegFilteringMode.Mode int mode,
      String sampleMimeType,
      String codecs,
      int nalLengthSize,
      byte[] data,
      int length,
      long timeUs,
      int flags);
}
