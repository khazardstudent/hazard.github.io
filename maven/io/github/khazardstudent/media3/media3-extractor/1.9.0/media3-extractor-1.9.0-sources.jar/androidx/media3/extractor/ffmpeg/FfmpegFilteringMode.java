/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ffmpeg;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.LOCAL_VARIABLE;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;

import androidx.annotation.IntDef;
import androidx.media3.common.util.UnstableApi;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Modes for the FFmpeg-based HDR/DV filtering pipeline. */
@UnstableApi
public final class FfmpegFilteringMode {

  /** Let the helper choose based on device/display capabilities. */
  public static final int AUTO = 0;
  /** Keep Dolby Vision (drop HDR10+/HDR10 metadata). */
  public static final int KEEP_DOLBY_VISION = 1;
  /** Keep HDR10/HDR10+ base layer (drop Dolby Vision metadata). */
  public static final int KEEP_HDR10_BASE = 2;
  /** Keep Dolby Vision (drop FEL enhancement layer only). */
  public static final int KEEP_DOLBY_VISION_MEL = 3;

  @IntDef({AUTO, KEEP_DOLBY_VISION, KEEP_HDR10_BASE, KEEP_DOLBY_VISION_MEL})
  @Retention(RetentionPolicy.SOURCE)
  public @interface Mode {}

  private FfmpegFilteringMode() {}
}
