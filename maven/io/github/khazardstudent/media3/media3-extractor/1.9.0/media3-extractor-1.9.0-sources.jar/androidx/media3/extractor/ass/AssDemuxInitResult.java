/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.extractor.ass;

import androidx.media3.common.util.UnstableApi;
import com.google.common.collect.ImmutableList;
import java.util.List;

/** Initialization data extracted from MKV before packet pumping starts. */
@UnstableApi
public final class AssDemuxInitResult {

  /** ASS/SSA text tracks discovered in the container. */
  public final ImmutableList<AssStreamFormatInfo> tracks;

  /** Attachment payloads (typically embedded fonts). */
  public final ImmutableList<AssAttachmentInfo> attachments;

  public AssDemuxInitResult(
      List<AssStreamFormatInfo> tracks, List<AssAttachmentInfo> attachments) {
    this.tracks = ImmutableList.copyOf(tracks);
    this.attachments = ImmutableList.copyOf(attachments);
  }
}

