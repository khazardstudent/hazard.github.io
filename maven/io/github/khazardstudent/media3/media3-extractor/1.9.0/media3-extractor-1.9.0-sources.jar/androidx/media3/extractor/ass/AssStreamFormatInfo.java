/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.extractor.ass;

import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;

/** Stream metadata required to initialize libass for a selected ASS/SSA track. */
@UnstableApi
public final class AssStreamFormatInfo {

  /** Demux track identifier. */
  public final int trackId;

  /** MKV codec identifier (for example, S_TEXT/ASS). */
  public final String codecId;

  /** Optional BCP-47 language tag or container language value. */
  @Nullable public final String language;

  /** Codec private/extradata payload to be passed to libass. */
  public final byte[] codecPrivate;

  /** Timebase numerator for packet timestamp conversion. */
  public final long timebaseNum;

  /** Timebase denominator for packet timestamp conversion. */
  public final long timebaseDen;

  public AssStreamFormatInfo(
      int trackId,
      String codecId,
      @Nullable String language,
      byte[] codecPrivate,
      long timebaseNum,
      long timebaseDen) {
    this.trackId = trackId;
    this.codecId = codecId;
    this.language = language;
    this.codecPrivate = codecPrivate;
    this.timebaseNum = timebaseNum;
    this.timebaseDen = timebaseDen;
  }
}

