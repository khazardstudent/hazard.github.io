/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ffmpeg;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.ExtractorsFactory;

/**
 * ExtractorsFactory that prepends a native-friendly MKV extractor and wraps delegate extractors
 * with the FFmpeg filtering adapter.
 */
@UnstableApi
public final class NativeMkvExtractorsFactory implements ExtractorsFactory {

  private final ExtractorsFactory delegate;
  private final @FfmpegFilteringMode.Mode int mode;

  public NativeMkvExtractorsFactory(ExtractorsFactory delegate, @FfmpegFilteringMode.Mode int mode) {
    this.delegate = delegate;
    this.mode = mode;
  }

  @Override
  public Extractor[] createExtractors() {
    Extractor[] baseExtractors = delegate.createExtractors();
    Extractor[] wrapped = new Extractor[baseExtractors.length + 1];
    wrapped[0] = new NativeMkvExtractor(mode);
    for (int i = 0; i < baseExtractors.length; i++) {
      wrapped[i + 1] = new FfmpegFilteringExtractorAdapter(baseExtractors[i], mode);
    }
    return wrapped;
  }
}
