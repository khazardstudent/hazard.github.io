/*
 * Binding for a native FFmpeg-based MKV demuxer.
 *
 * <p>The demux implementation currently exposes a safe fallback-first API surface so Java-side
 * integration can proceed while native packet extraction is completed incrementally.
 */
package androidx.media3.extractor.ffmpeg;

import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.extractor.ass.AssDemuxInitResult;
import androidx.media3.extractor.ass.AssPacketInfo;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

@UnstableApi
public final class NativeMkvDemuxer implements AutoCloseable {

  private static final String TAG = "NativeMkvDemuxer";
  private static final boolean LIB_LOADED;

  static {
    boolean loaded;
    try {
      System.loadLibrary("ffmpegmkvdemuxer");
      loaded = true;
    } catch (UnsatisfiedLinkError e) {
      loaded = false;
    }
    LIB_LOADED = loaded;
  }

  private final @FfmpegFilteringMode.Mode int mode;
  private long handle;
  private boolean opened;
  @Nullable private HttpPipeBridge httpPipeBridge;

  public NativeMkvDemuxer(@FfmpegFilteringMode.Mode int mode) {
    this.mode = mode;
    if (LIB_LOADED) {
      handle = nativeCreate();
    }
  }

  /** Returns whether the native library loaded successfully. */
  public static boolean isAvailable() {
    return LIB_LOADED;
  }

  /** Attempts to open the demuxer; returns true if native path should be used. */
  public boolean open() {
    if (!LIB_LOADED || handle == 0) {
      return false;
    }
    opened = nativeOpen(handle);
    return opened;
  }

  /**
   * Opens the demuxer against a network/file URI.
   *
   * <p>Header keys and values are passed in map-iteration order, using parallel arrays.
   */
  public boolean open(String uri, @Nullable Map<String, String> headers) {
    if (!LIB_LOADED || handle == 0) {
      return false;
    }
    closeHttpPipeBridge();
    String normalizedUri = normalizeUriForNativeOpen(uri);
    String[] headerKeys;
    String[] headerValues;
    if (headers == null || headers.isEmpty()) {
      headerKeys = new String[0];
      headerValues = new String[0];
    } else {
      headerKeys = new String[headers.size()];
      headerValues = new String[headers.size()];
      int i = 0;
      for (Map.Entry<String, String> entry : headers.entrySet()) {
        headerKeys[i] = entry.getKey();
        headerValues[i] = entry.getValue() != null ? entry.getValue() : "";
        i++;
      }
    }
    opened = nativeOpenUri(handle, normalizedUri, headerKeys, headerValues);
    // Retry the original URI if normalization changed it and open still failed.
    if (!opened && !normalizedUri.equals(uri)) {
      opened = nativeOpenUri(handle, uri, headerKeys, headerValues);
    }
    if (!opened && isHttpUri(normalizedUri)) {
      @Nullable HttpPipeBridge bridge = HttpPipeBridge.create(normalizedUri, headers);
      if (bridge != null) {
        opened = nativeOpenUri(handle, bridge.getReadFdPath(), new String[0], new String[0]);
        if (opened) {
          httpPipeBridge = bridge;
          Log.i(TAG, "Opened demuxer using HTTP pipe fallback");
        } else {
          bridge.close();
        }
      }
    }
    return opened;
  }

  /**
   * Normalizes URL characters that FFmpeg's URL parser rejects when passed unescaped.
   *
   * <p>Brackets are common in torrent-style file names, but must be percent-encoded in HTTP URLs.
   */
  private static String normalizeUriForNativeOpen(String uri) {
    String normalized = uri;
    if (normalized.indexOf('[') >= 0 || normalized.indexOf(']') >= 0 || normalized.indexOf(' ') >= 0) {
      normalized = normalized.replace("[", "%5B").replace("]", "%5D").replace(" ", "%20");
    }
    return normalized;
  }

  public boolean includeFilter(String codec, String filterName) {
    if (!opened || handle == 0) {
      return false;
    }
    return nativeIncludeFilter(handle, codec, filterName);
  }

  /** Steps demux; returns number of samples emitted (stubbed to 0 for now). */
  public int demux() {
    if (!opened || handle == 0) {
      return 0;
    }
    return nativeDemux(handle);
  }

  public boolean seek(long positionUs) {
    if (!opened || handle == 0) {
      return false;
    }
    if (httpPipeBridge != null) {
      Log.w(TAG, "seek unavailable on HTTP pipe fallback input");
      return false;
    }
    return nativeSeek(handle, positionUs);
  }

  /** Returns whether the demuxer is currently reading via HTTP pipe fallback. */
  public boolean isUsingHttpPipeFallback() {
    return httpPipeBridge != null;
  }

  /** Reads demux initialization metadata (ASS tracks and attachments), if available. */
  @Nullable
  public AssDemuxInitResult readInitResult() {
    if (!opened || handle == 0) {
      return null;
    }
    return nativeReadInitResult(handle);
  }

  /** Selects the ASS/SSA text track to pump packets from. */
  public boolean selectAssTrack(int trackId) {
    if (!opened || handle == 0) {
      return false;
    }
    return nativeSelectAssTrack(handle, trackId);
  }

  /**
   * Reads the next ASS packet for the selected track.
   *
   * @param timeoutMs timeout in milliseconds. Values &lt; 0 are clamped to 0.
   */
  @Nullable
  public AssPacketInfo readNextAssPacket(long timeoutMs) {
    if (!opened || handle == 0) {
      return null;
    }
    return nativeReadNextAssPacket(handle, Math.max(0L, timeoutMs));
  }

  /** Returns whether the selected ASS stream has reached end-of-input. */
  public boolean isAssEof() {
    if (!opened || handle == 0) {
      return false;
    }
    return nativeIsAssEof(handle);
  }

  /** Flushes pending demux state after seek/discontinuity. */
  public void flush() {
    if (!opened || handle == 0) {
      return;
    }
    nativeFlush(handle);
  }

  @Override
  public void close() {
    if (handle != 0) {
      nativeClose(handle);
      handle = 0;
      opened = false;
    }
    closeHttpPipeBridge();
  }

  private static boolean isHttpUri(String uri) {
    @Nullable String scheme = Uri.parse(uri).getScheme();
    return "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme);
  }

  private void closeHttpPipeBridge() {
    if (httpPipeBridge != null) {
      httpPipeBridge.close();
      httpPipeBridge = null;
    }
  }

  private static native long nativeCreate();

  private static native boolean nativeOpen(long handle);

  private static native boolean nativeOpenUri(
      long handle, String uri, String[] headerKeys, String[] headerValues);

  private static native void nativeClose(long handle);

  private static native boolean nativeIncludeFilter(long handle, String codec, String filterName);

  private static native int nativeDemux(long handle);

  private static native boolean nativeSeek(long handle, long positionUs);

  @Nullable
  private static native AssDemuxInitResult nativeReadInitResult(long handle);

  private static native boolean nativeSelectAssTrack(long handle, int trackId);

  @Nullable
  private static native AssPacketInfo nativeReadNextAssPacket(long handle, long timeoutMs);

  private static native boolean nativeIsAssEof(long handle);

  private static native void nativeFlush(long handle);

  private static final class HttpPipeBridge implements Closeable {

    private static final int IO_BUFFER_SIZE = 64 * 1024;
    private static final int CONNECT_TIMEOUT_MS = 15_000;
    private static final int READ_TIMEOUT_MS = 30_000;

    private final String uri;
    private final @Nullable Map<String, String> headers;
    private final ParcelFileDescriptor readFd;
    private final ParcelFileDescriptor writeFd;
    private final Thread pumpThread;

    @Nullable private volatile HttpURLConnection connection;
    private volatile boolean closed;

    @Nullable
    public static HttpPipeBridge create(String uri, @Nullable Map<String, String> headers) {
      try {
        ParcelFileDescriptor[] pipe = ParcelFileDescriptor.createPipe();
        HttpPipeBridge bridge = new HttpPipeBridge(uri, headers, pipe[0], pipe[1]);
        bridge.start();
        return bridge;
      } catch (IOException e) {
        Log.w(TAG, "Failed to create HTTP pipe bridge", e);
        return null;
      }
    }

    private HttpPipeBridge(
        String uri,
        @Nullable Map<String, String> headers,
        ParcelFileDescriptor readFd,
        ParcelFileDescriptor writeFd) {
      this.uri = uri;
      this.headers = headers;
      this.readFd = readFd;
      this.writeFd = writeFd;
      this.pumpThread = new Thread(this::pumpLoop, "ffmpeg-http-pipe");
    }

    public void start() {
      pumpThread.start();
    }

    public String getReadFdPath() {
      return "/proc/self/fd/" + readFd.getFd();
    }

    private void pumpLoop() {
      try (OutputStream outputStream = new ParcelFileDescriptor.AutoCloseOutputStream(writeFd)) {
        HttpURLConnection localConnection = null;
        try {
          localConnection = (HttpURLConnection) new URL(uri).openConnection();
          connection = localConnection;
          localConnection.setInstanceFollowRedirects(true);
          localConnection.setConnectTimeout(CONNECT_TIMEOUT_MS);
          localConnection.setReadTimeout(READ_TIMEOUT_MS);
          if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
              if (entry.getKey() != null && entry.getValue() != null) {
                localConnection.setRequestProperty(entry.getKey(), entry.getValue());
              }
            }
          }
          localConnection.connect();
          try (InputStream inputStream = localConnection.getInputStream()) {
            byte[] buffer = new byte[IO_BUFFER_SIZE];
            int read;
            while (!closed && (read = inputStream.read(buffer)) != -1) {
              outputStream.write(buffer, 0, read);
            }
            outputStream.flush();
          }
        } finally {
          if (localConnection != null) {
            localConnection.disconnect();
          }
          connection = null;
        }
      } catch (IOException e) {
        if (!closed) {
          Log.w(TAG, "HTTP pipe streaming failed", e);
        }
      }
    }

    @Override
    public void close() {
      closed = true;
      @Nullable HttpURLConnection localConnection = connection;
      if (localConnection != null) {
        localConnection.disconnect();
      }
      closeQuietly(writeFd);
      closeQuietly(readFd);
      pumpThread.interrupt();
    }

    private static void closeQuietly(ParcelFileDescriptor pfd) {
      try {
        pfd.close();
      } catch (IOException ignored) {
      }
    }
  }
}
