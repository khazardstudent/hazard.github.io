/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ffmpeg;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.ExtractorInput;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.PositionHolder;
import androidx.media3.extractor.mkv.MatroskaExtractor;
import java.io.IOException;
import android.util.Log;

/**
 * MKV extractor that prefers a native FFmpeg demuxer; currently delegates to the built-in Matroska
 * extractor but wraps outputs with FFmpeg filtering so the integration point is isolated.
 *
 * <p>This class exists to make it easier to swap in a native MKV demuxer without touching higher
 * layers. For now it uses {@link MatroskaExtractor} and {@link FfmpegFilteringSession} to apply
 * filtering in the Java pipeline.
 */
@UnstableApi
public final class NativeMkvExtractor implements Extractor {

  private static final String TAG = "NativeMkvExtractor";

  private final @FfmpegFilteringMode.Mode int mode;
  private final MatroskaExtractor delegate;
  private final FfmpegFilteringSession session;
  @SuppressWarnings("unused")
  private final NativeMkvDemuxer nativeDemuxer;
  private boolean initialized;
  private boolean nativeReady;

  public NativeMkvExtractor(@FfmpegFilteringMode.Mode int mode) {
    this.mode = mode;
    this.delegate = new MatroskaExtractor();
    this.session = FfmpegFilteringSession.create(mode);
    this.nativeDemuxer = new NativeMkvDemuxer(mode);
    if (NativeMkvDemuxer.isAvailable()) {
      nativeReady = nativeDemuxer.open();
      Log.i(TAG, "Native MKV demuxer available=" + nativeReady);
    } else {
      nativeReady = false;
    }
  }

  @Override
  public boolean sniff(ExtractorInput input) throws IOException {
    // Use Matroska sniff for now; native demuxer can be added later.
    return delegate.sniff(input);
  }

  @Override
  public void init(ExtractorOutput output) {
    if (initialized) {
      return;
    }
    initialized = true;
    // TODO: When native demuxer is implemented, swap to a native output path here.
    if (nativeReady && session.isActive()) {
      delegate.init(new FilteringExtractorOutput(output, session));
    } else if (session.isActive()) {
      delegate.init(new FilteringExtractorOutput(output, session));
    } else {
      delegate.init(output);
    }
  }

  @Override
  public int read(ExtractorInput input, PositionHolder seekPosition) throws IOException {
    return delegate.read(input, seekPosition);
  }

  @Override
  public void seek(long position, long timeUs) {
    delegate.seek(position, timeUs);
  }

  @Override
  public void release() {
    delegate.release();
    session.close();
    nativeDemuxer.close();
  }
}
